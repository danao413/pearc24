from ase.calculators.mixing import SumCalculator as SC 
from ase.io import read 
from ase.optimize import LBFGS 
from dftd3.ase import DFTD3 
from gpaw import GPAW, PW 
s = read("input.cif") 
dft = GPAW(xc = 'PBE', kpts = (4, 4, 4), mode = PW(600), occupations = {'name': 'fermi-dirac', 'width': 0.1}, convergence = {'energy': 10e-6}) 
d3 = DFTD3(method="PBE", damping="d3bj") 
s.calc = SC([d3, dft]) 
opt = LBFGS(s, logfile="dft.out") 
opt.run() 
