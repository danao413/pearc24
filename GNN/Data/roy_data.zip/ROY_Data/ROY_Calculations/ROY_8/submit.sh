#!/bin/bash 
#SBATCH -J DFT 
#SBATCH -N 1 
#SBATCH -n 32 
#SBATCH -o j_%j.out 
#SBATCH -p RM 
#SBATCH -A cis210015p 
#SBATCH -t 24:00:00 
ulimit -s unlimited 
ulimit -v unlimited 
module load anaconda3 
source activate /ocean/projects/cis210015p/danao/envs/ase/ 
export GPAW_SETUP_PATH='/ocean/projects/cis210015p/danao/GNN/DFT/gpaw-setups-0.9.20000/' 
python dft.py 
